  'use strict';
$(function() {
    /*time*/
    $(".hour-mask").inputmask({ mask: "99:99:99"});
  });